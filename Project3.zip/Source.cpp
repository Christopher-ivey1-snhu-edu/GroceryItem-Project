/*Christopher Ivey 
Programming Languanges C++/ Python Project 3*/



#include <Python.h>
#include <iostream>
#include <Windows.h>
#include <cmath>
#include <string>
#include <vector>
#include <fstream>

using namespace std;

vector<string> Citems;
vector<int> Ccounts;

/*
Description:
	To call this function, simply pass the function name in Python that you wish to call.
Example:
	callProcedure("myPythonConnect");
Output:
	Python will print on the screen: Hello from python!
Return:
	None
*/
void CallProcedure(string pName)//used this to call any python function that does *not* have any parameters
{
	char* procname = new char[pName.length() + 1];
	std::strcpy(procname, pName.c_str());

	Py_Initialize();
	PyObject* my_module = PyImport_ImportModule("myPythonConnect");//changed file name to my .py file
	PyErr_Print();
	PyObject* my_function = PyObject_GetAttrString(my_module, procname);
	PyObject* my_result = PyObject_CallObject(my_function, NULL);
	Py_Finalize();

	delete[] procname;
}
/*
Description:
		To call this function, pass the name of the Python functino you wish to call and the string parameter you want to send
Example:
		int x = callIntFunc("PrintMe","Test");
Output:
		Python will print on the screen:
				You sent me: Test
Return:
		100 is returned to the C++
*/
int callIntFunc(string proc, string param)
{
	char* procname = new char[proc.length() + 1];
	std::strcpy(procname, proc.c_str());

	char* paramval = new char[param.length() + 1];
	std::strcpy(paramval, param.c_str());


	PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
	// Initialize the Python Interpreter
	Py_Initialize();
	// Build the name object
	pName = PyUnicode_FromString((char*)"myPythonConnect");
	// Load the module object
	pModule = PyImport_Import(pName);
	// pDict is a borrowed reference 
	pDict = PyModule_GetDict(pModule);
	// pFunc is also a borrowed reference 
	pFunc = PyDict_GetItemString(pDict, procname);
	if (PyCallable_Check(pFunc))
	{
		pValue = Py_BuildValue("(z)", paramval);
		PyErr_Print();
		presult = PyObject_CallObject(pFunc, pValue);
		PyErr_Print();
	}
	else
	{
		PyErr_Print();
	}
	//printf("Result is %d\n", _PyLong_AsInt(presult));
	Py_DECREF(pValue);
	// Clean up
	Py_DECREF(pModule);
	Py_DECREF(pName);
	// Finish the Python Interpreter
	Py_Finalize();

	// clean 
	delete[] procname;
	delete[] paramval;


	return _PyLong_AsInt(presult);
}


void DisplayMenu() {
	cout << "*******Choose from the options below*******" << endl;
	cout << "Type 1 in the keyboard to: See total Sales Count list" << endl;
	cout << "Type 2 in the keyboard to: See Sales Count for Each Individual Item" << endl;
	cout << "Type 3 in the keyboard to: See Histogram of Item Sales" << endl;
	cout << "Type 4: Exit the Program." << endl;
}

void CreateHistogram(char dispChar) {
	/*Loop through the newly created file and read the name and frequency on each row.
				Then print the name, followed by asterisks or another special character to represent the numeric amount.
				The number of asterisks should equal the frequency read from the file. */
	int i;
	for (i = 0; i < Citems.size(); ++i) {
		cout << Citems.at(i) << "    \t" << std::string(Ccounts.at(i), dispChar) << endl;
	}
}
void ReadFile(string fileName) {
	string itemCount;
	ifstream file(fileName);
	string item;
	int count;

	getline(file, itemCount, '\n');//read first line of file into itemCount string
	while (!file.fail())//loop through until end of file is reached
	{
		//split itemCount into the separate item and count parts
		item = itemCount.substr(0, itemCount.rfind(' '));
		count = stoi(itemCount.substr(itemCount.rfind(' ')));

		//add count to count vector
		Ccounts.push_back(count);
		Citems.push_back(item);//add item to item name vector

		getline(file, itemCount, '\n');//get next line in the file
	}
	file.close();//close file
	return;

}

int main()
{
	string userChoice;
	string item;
	//ReadFile();
	DisplayMenu();
	cin >> userChoice;
	while (userChoice != "4") {
		if (userChoice == "1") {//This is the C++ code for when a user selects Option 1 from the Menu. 

			CallProcedure("CountAllItems");//This is how you select and apply a C++ function to call the appropriate Python function, which will display the number of times each item (or word) appears.
		}
		else if (userChoice == "2") {//Use C++ to validate user input for option 2 in the menu.

			cout << "Which item are you searching for?" << endl;
			cin >> item;//Prompt a user to input the item, or word, they wish to look for.
			cout << "There were " << callIntFunc("ItemCount", item) << " " << item <<  endl;//Write a C++ function to take the user�s input and pass it to Python.
		}
		else if (userChoice == "3") {//This is how you use C++ to validate user input for option 3 in the menu.
			//Call python to create teh frequency.dat file
			CallProcedure("CreateItemsFile");
			//Write C++ code to read the frequency.dat file and display a histogram.
			ReadFile("frequency.dat");
			CreateHistogram('*');
		}
		else {
			cout << "Wrong Input."<<endl<<"Please Enter in correct Input!";
		}
		cout << endl;
		DisplayMenu();
		cin >> userChoice;
	}
	cout << "Thanks, Goodbye!";

}

